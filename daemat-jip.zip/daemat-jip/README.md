# 🍽️ 대맛집 — 대전 맛집 공유 플랫폼

대전 시민과 관광객이 맛집을 등록하고 실시간으로 공유하는 커뮤니티형 웹 서비스입니다.

- **기술 스택**: Next.js 14 (App Router) · React 18 · TypeScript · Tailwind CSS · Firebase (Auth / Firestore / Storage) · Framer Motion · Kakao Map
- **배포**: Vercel

---

## 1. 폴더 구조

```
daemat-jip/
├─ app/
│  ├─ layout.tsx              # 루트 레이아웃 (Header/Footer/AuthProvider)
│  ├─ page.tsx                 # 홈 (Hero, 카테고리, 지도, 목록)
│  ├─ globals.css
│  ├─ loading.tsx / not-found.tsx
│  ├─ robots.ts
│  ├─ register/page.tsx        # 맛집 등록
│  ├─ restaurants/[id]/page.tsx # 맛집 상세
│  ├─ mypage/page.tsx           # 마이페이지 + 관리자 패널
│  └─ favorites/page.tsx        # 즐겨찾기
├─ components/                  # Header, Hero, CategoryFilter, RestaurantCard,
│                                # RestaurantGrid, MapView, LocationPicker,
│                                # ImageUploader, CommentSection, LikeButton,
│                                # ShareButton, LoginModal, Footer, ScrollReveal
├─ hooks/                       # useAuth, useRestaurants, useComments, useLikes
├─ lib/                         # firebase.ts (초기화), utils.ts
├─ types/                       # 공용 타입 정의
├─ firebase/                    # firestore.rules, storage.rules, indexes.json
├─ public/
├─ .env.local.example
└─ package.json
```

---

## 2. 로컬 실행 방법

```bash
# 1) 패키지 설치
npm install

# 2) 환경변수 설정
cp .env.local.example .env.local
# .env.local 파일을 열어 Firebase / Kakao 키를 입력하세요

# 3) 개발 서버 실행
npm run dev
```

브라우저에서 http://localhost:3000 접속.

---

## 3. Firebase 연결 방법

### 3-1. 프로젝트 생성
1. [Firebase Console](https://console.firebase.google.com)에서 새 프로젝트 생성
2. "웹 앱 추가"를 눌러 앱을 등록하고 `firebaseConfig` 값을 확인

### 3-2. Authentication 설정
1. Authentication → Sign-in method 에서 **Google**과 **이메일/비밀번호** 로그인 활성화
2. Google 로그인은 승인된 도메인에 배포 도메인(예: `your-app.vercel.app`)을 추가

### 3-3. Firestore Database 설정
1. Firestore Database → 데이터베이스 만들기 (프로덕션 모드)
2. 컬렉션 구조:
   - `users/{uid}` — 사용자 프로필 (닉네임, role, favorites 등)
   - `restaurants/{id}` — 맛집 게시글
   - `restaurants/{id}/likes/{uid}` — 좋아요 서브컬렉션
   - `comments/{id}` — 댓글 (restaurantId, parentId 필드로 구조화)
   - `reports/{id}` — 신고 내역
3. 보안 규칙 배포:
   ```bash
   firebase deploy --only firestore:rules,firestore:indexes
   ```
   (`firebase/firestore.rules`, `firebase/firestore.indexes.json` 파일 사용)
4. 콘솔에 색인 생성 오류가 뜨면, 에러 메시지에 포함된 링크를 눌러 자동 생성하거나
   `firebase/firestore.indexes.json`을 참고해 수동으로 추가하세요.

### 3-4. Storage 설정
1. Storage 시작하기 → 기본 버킷 생성
2. 보안 규칙 배포:
   ```bash
   firebase deploy --only storage
   ```
   (`firebase/storage.rules` 사용)

### 3-5. 관리자 계정 지정
- `.env.local`의 `NEXT_PUBLIC_ADMIN_EMAILS`에 관리자 이메일을 콤마로 구분하여 입력하면,
  해당 이메일로 처음 가입 시 자동으로 `role: "admin"`이 부여됩니다.
- 이미 가입한 사용자를 관리자로 바꾸려면 Firestore 콘솔에서 `users/{uid}` 문서의
  `role` 필드를 `"admin"`으로 직접 수정하세요.

---

## 4. Kakao 지도 API 설정

1. [Kakao Developers](https://developers.kakao.com) 에서 애플리케이션 생성
2. "플랫폼 설정 → Web"에 사이트 도메인 등록 (예: `http://localhost:3000`, 배포 도메인)
3. "앱 키 → JavaScript 키"를 `.env.local`의 `NEXT_PUBLIC_KAKAO_MAP_API_KEY`에 입력

> 키가 없어도 앱은 정상 동작하며, 지도 영역에 안내 문구가 표시되고
> 맛집 등록 시 위도/경도를 직접 입력하는 방식으로 대체됩니다.

---

## 5. 환경 변수 (.env.local)

```env
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=
NEXT_PUBLIC_KAKAO_MAP_API_KEY=
NEXT_PUBLIC_ADMIN_EMAILS=
```

---

## 6. Vercel 배포 방법

1. GitHub에 저장소를 만들고 이 프로젝트를 푸시
2. [vercel.com](https://vercel.com) → "Add New Project" → 해당 저장소 선택
3. **Environment Variables**에 `.env.local`에 입력했던 모든 값을 동일하게 등록
4. Framework Preset은 자동으로 **Next.js**가 인식됩니다. Deploy 클릭
5. 배포 완료 후 Firebase Authentication의 "승인된 도메인"과
   Kakao Developers의 "Web 플랫폼 도메인"에 배포된 주소(`https://xxx.vercel.app`)를 추가

---

## 7. 유지보수 가이드

| 작업 | 위치 |
| --- | --- |
| 카테고리 추가/변경 | `types/index.ts`의 `CATEGORIES`, `components/CategoryFilter.tsx`의 `ICONS` |
| 메인 컬러 변경 | `tailwind.config.ts`의 `theme.extend.colors.brand` |
| 검색 로직 수정 | `hooks/useRestaurants.ts` |
| 등록 폼 필드 추가 | `types/index.ts`의 `Restaurant` 타입 + `app/register/page.tsx` |
| 신고 기능 UI 추가 | `app/restaurants/[id]/page.tsx`에 신고 버튼 → `reports` 컬렉션에 `addDoc` |
| 보안 규칙 변경 | `firebase/firestore.rules`, `firebase/storage.rules` 수정 후 `firebase deploy` |
| 이미지 업로드 용량/개수 제한 | `components/ImageUploader.tsx`의 `max` prop, `firebase/storage.rules`의 용량 조건 |

### 정기 점검 체크리스트
- Firestore 사용량(읽기/쓰기 횟수)이 무료 할당량을 넘지 않는지 콘솔에서 확인
- Storage 용량 확인 및 오래된 미사용 이미지 정리
- 신고된 게시글은 마이페이지 관리자 패널에서 주기적으로 확인
- `npm outdated`로 패키지 버전 점검 후 필요 시 업데이트

---

## 8. 참고 사항 (신고 버튼 추가 예시)

현재 신고 관리 화면(마이페이지)은 구현되어 있지만, 사용자가 신고를 "제출"하는
버튼은 기본 골격만 안내되어 있습니다. 상세 페이지에 아래와 같은 방식으로 추가할 수 있습니다.

```tsx
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";

async function reportRestaurant(restaurantId: string, reporterId: string, reason: string) {
  await addDoc(collection(db, "reports"), {
    restaurantId,
    reporterId,
    reason,
    resolved: false,
    createdAt: serverTimestamp(),
  });
}
```
