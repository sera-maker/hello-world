"use client";

import { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/hooks/useAuth";
import { Restaurant } from "@/types";
import RestaurantGrid from "@/components/RestaurantGrid";

export default function FavoritesPage() {
  const { user, appUser, loading } = useAuth();
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [fetching, setFetching] = useState(true);

  useEffect(() => {
    if (!appUser) return;
    const load = async () => {
      setFetching(true);
      const results = await Promise.all(
        appUser.favorites.map(async (id) => {
          const snap = await getDoc(doc(db, "restaurants", id));
          return snap.exists() ? ({ id: snap.id, ...snap.data() } as Restaurant) : null;
        })
      );
      setRestaurants(results.filter((r): r is Restaurant => r !== null));
      setFetching(false);
    };
    load();
  }, [appUser]);

  if (loading) return <div className="py-24 text-center">불러오는 중...</div>;

  if (!user) {
    return (
      <div className="py-24 text-center text-accent-brown/60">
        로그인 후 즐겨찾기를 확인할 수 있어요.
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="mb-6 text-2xl font-extrabold text-accent-brown">
        ⭐ 내가 즐겨찾기한 맛집
      </h1>
      <RestaurantGrid restaurants={restaurants} loading={fetching} />
    </div>
  );
}
