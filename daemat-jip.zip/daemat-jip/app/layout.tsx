import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/hooks/useAuth";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "대맛집 | 대전 맛집 공유 플랫폼",
  description:
    "대전 시민과 관광객이 함께 만들어가는 대전 맛집 커뮤니티, 대맛집. 숨은 맛집을 등록하고 공유해보세요.",
  keywords: ["대전맛집", "대전 맛집 추천", "대전 카페", "대전 맛집 지도"],
  openGraph: {
    title: "대맛집 | 대전 맛집 공유 플랫폼",
    description: "대전의 숨은 맛집을 공유해보세요.",
    locale: "ko_KR",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ko">
      <body className="min-h-screen font-sans antialiased">
        <AuthProvider>
          <Header />
          <main className="min-h-[calc(100vh-64px)]">{children}</main>
          <Footer />
        </AuthProvider>
      </body>
    </html>
  );
}
