export default function Loading() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-3">
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-brand-200 border-t-brand-500" />
      <p className="text-sm text-accent-brown/50">대맛집을 불러오는 중...</p>
    </div>
  );
}
