"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  updateDoc,
  where,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/hooks/useAuth";
import { Report, Restaurant } from "@/types";
import RestaurantGrid from "@/components/RestaurantGrid";
import { ShieldAlert, Trash2 } from "lucide-react";

export default function MyPage() {
  const { user, appUser, isAdmin, loading } = useAuth();
  const [myRestaurants, setMyRestaurants] = useState<Restaurant[]>([]);
  const [myLoading, setMyLoading] = useState(true);
  const [reports, setReports] = useState<Report[]>([]);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, "restaurants"),
      where("authorId", "==", user.uid),
      orderBy("createdAt", "desc")
    );
    const unsub = onSnapshot(q, (snap) => {
      setMyRestaurants(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Restaurant)));
      setMyLoading(false);
    });
    return () => unsub();
  }, [user]);

  useEffect(() => {
    if (!isAdmin) return;
    const q = query(
      collection(db, "reports"),
      where("resolved", "==", false),
      orderBy("createdAt", "desc")
    );
    const unsub = onSnapshot(q, (snap) => {
      setReports(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Report)));
    });
    return () => unsub();
  }, [isAdmin]);

  const resolveReport = async (reportId: string) => {
    await updateDoc(doc(db, "reports", reportId), { resolved: true });
  };

  const deleteReportedRestaurant = async (restaurantId: string, reportId: string) => {
    if (!confirm("이 맛집 게시글을 삭제하시겠어요?")) return;
    await deleteDoc(doc(db, "restaurants", restaurantId));
    await updateDoc(doc(db, "reports", reportId), { resolved: true });
  };

  if (loading) return <div className="py-24 text-center">불러오는 중...</div>;

  if (!user || !appUser) {
    return (
      <div className="py-24 text-center text-accent-brown/60">
        로그인 후 이용할 수 있는 페이지예요.
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <div className="mb-10 flex items-center gap-4 rounded-xl3 bg-white p-6 shadow-soft">
        {appUser.photoURL ? (
          <Image
            src={appUser.photoURL}
            alt={appUser.displayName}
            width={64}
            height={64}
            className="rounded-full"
          />
        ) : (
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-300 text-2xl font-bold">
            {appUser.displayName[0]}
          </div>
        )}
        <div>
          <p className="text-lg font-bold text-accent-brown">
            {appUser.displayName}
            {isAdmin && (
              <span className="ml-2 rounded-full bg-accent-brown px-2 py-0.5 text-xs text-white">
                관리자
              </span>
            )}
          </p>
          <p className="text-sm text-accent-brown/50">{appUser.email}</p>
        </div>
        <Link href="/favorites" className="btn-secondary ml-auto">
          즐겨찾기 보기
        </Link>
      </div>

      <h2 className="mb-4 text-lg font-bold text-accent-brown">
        내가 등록한 맛집 ({myRestaurants.length})
      </h2>
      <RestaurantGrid restaurants={myRestaurants} loading={myLoading} />

      {isAdmin && (
        <div className="mt-14">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-accent-brown">
            <ShieldAlert className="h-5 w-5" /> 신고 관리 ({reports.length})
          </h2>
          {reports.length === 0 ? (
            <p className="text-sm text-accent-brown/50">처리할 신고가 없어요.</p>
          ) : (
            <div className="flex flex-col gap-3">
              {reports.map((r) => (
                <div
                  key={r.id}
                  className="flex items-center justify-between rounded-xl2 bg-white p-4 shadow-soft"
                >
                  <div>
                    <p className="text-sm font-semibold text-accent-brown">
                      신고 사유: {r.reason}
                    </p>
                    <Link
                      href={`/restaurants/${r.restaurantId}`}
                      className="text-xs text-accent-orange"
                    >
                      게시글 확인하기 →
                    </Link>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => resolveReport(r.id)}
                      className="rounded-full border border-brand-300 px-4 py-1.5 text-xs font-semibold"
                    >
                      문제없음
                    </button>
                    <button
                      onClick={() => deleteReportedRestaurant(r.restaurantId, r.id)}
                      className="flex items-center gap-1 rounded-full bg-red-500 px-4 py-1.5 text-xs font-semibold text-white"
                    >
                      <Trash2 className="h-3 w-3" /> 게시글 삭제
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
