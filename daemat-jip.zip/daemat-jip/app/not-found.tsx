import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 px-4 text-center">
      <span className="text-6xl">🍜</span>
      <h1 className="text-xl font-bold text-accent-brown">
        페이지를 찾을 수 없어요
      </h1>
      <p className="text-sm text-accent-brown/60">
        찾으시는 맛집이나 페이지가 존재하지 않아요.
      </p>
      <Link href="/" className="btn-primary">
        홈으로 돌아가기
      </Link>
    </div>
  );
}
