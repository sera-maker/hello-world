"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Hero from "@/components/Hero";
import CategoryFilter from "@/components/CategoryFilter";
import RestaurantGrid from "@/components/RestaurantGrid";
import MapView from "@/components/MapView";
import ScrollReveal from "@/components/ScrollReveal";
import { useRestaurants } from "@/hooks/useRestaurants";
import { Category } from "@/types";

function HomeContent() {
  const searchParams = useSearchParams();
  const q = searchParams.get("q") || "";
  const [category, setCategory] = useState<Category | "전체">("전체");
  const { restaurants, loading } = useRestaurants({ category, searchTerm: q });

  return (
    <div>
      <Hero />

      <section id="restaurants" className="mx-auto max-w-6xl py-10">
        <ScrollReveal className="px-4">
          <h2 className="mb-1 text-xl font-bold text-accent-brown">
            {q ? `"${q}" 검색 결과` : "지금 뜨는 대전 맛집"}
          </h2>
          <p className="mb-5 text-sm text-accent-brown/50">
            카테고리를 선택해서 원하는 맛집을 찾아보세요.
          </p>
        </ScrollReveal>

        <CategoryFilter value={category} onChange={setCategory} />

        <ScrollReveal className="mt-6 px-4" delay={100}>
          <MapView restaurants={restaurants} />
        </ScrollReveal>

        <div className="mt-8">
          <RestaurantGrid restaurants={restaurants} loading={loading} />
        </div>
      </section>
    </div>
  );
}

export default function HomePage() {
  return (
    <Suspense fallback={<div className="py-20 text-center">불러오는 중...</div>}>
      <HomeContent />
    </Suspense>
  );
}
