"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/hooks/useAuth";
import { CATEGORIES, Category } from "@/types";
import ImageUploader from "@/components/ImageUploader";
import LocationPicker from "@/components/LocationPicker";
import { motion } from "framer-motion";

export default function RegisterPage() {
  const { user, appUser, loading } = useAuth();
  const router = useRouter();

  const [name, setName] = useState("");
  const [category, setCategory] = useState<Category>("한식");
  const [address, setAddress] = useState("");
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(
    null
  );
  const [menu, setMenu] = useState("");
  const [priceRange, setPriceRange] = useState("");
  const [openingHours, setOpeningHours] = useState("");
  const [description, setDescription] = useState("");
  const [recommendReason, setRecommendReason] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);

  if (!loading && !user) {
    return (
      <div className="mx-auto max-w-lg px-4 py-24 text-center">
        <p className="mb-4 text-lg font-semibold text-accent-brown">
          맛집을 등록하려면 로그인이 필요해요.
        </p>
        <p className="text-sm text-accent-brown/60">
          우측 상단의 로그인 버튼을 눌러주세요.
        </p>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !appUser) return;
    if (!location) {
      alert("지도에서 맛집의 위치를 선택해주세요.");
      return;
    }
    if (images.length === 0) {
      alert("대표 사진을 최소 1장 업로드해주세요.");
      return;
    }

    setSubmitting(true);
    try {
      const docRef = await addDoc(collection(db, "restaurants"), {
        name,
        category,
        address,
        location,
        menu,
        priceRange,
        openingHours,
        description,
        recommendReason,
        images,
        authorId: user.uid,
        authorName: appUser.displayName,
        authorPhotoURL: appUser.photoURL || null,
        likeCount: 0,
        commentCount: 0,
        viewCount: 0,
        reported: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      router.push(`/restaurants/${docRef.id}`);
    } catch (err) {
      console.error("맛집 등록 실패:", err);
      alert("등록 중 문제가 발생했습니다. 다시 시도해주세요.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <motion.h1
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-2 text-2xl font-extrabold text-accent-brown"
      >
        🍽️ 맛집 등록하기
      </motion.h1>
      <p className="mb-8 text-sm text-accent-brown/60">
        내가 발견한 대전의 숨은 맛집을 다른 사람들과 나눠보세요.
      </p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-6">
        <Field label="대표 사진">
          <ImageUploader
            images={images}
            onChange={setImages}
            userId={user?.uid || "guest"}
          />
        </Field>

        <Field label="맛집 이름">
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="예) 성심당 본점"
            className="input-base"
          />
        </Field>

        <Field label="카테고리">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as Category)}
            className="input-base"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </Field>

        <Field label="주소">
          <input
            required
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="예) 대전광역시 중구 대종로480번길 15"
            className="input-base"
          />
        </Field>

        <Field label="지도 위치">
          <LocationPicker value={location} onChange={setLocation} />
        </Field>

        <Field label="대표 메뉴">
          <input
            required
            value={menu}
            onChange={(e) => setMenu(e.target.value)}
            placeholder="예) 튀김소보로, 보문산빵"
            className="input-base"
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="가격대">
            <input
              value={priceRange}
              onChange={(e) => setPriceRange(e.target.value)}
              placeholder="예) 5,000원 ~ 10,000원"
              className="input-base"
            />
          </Field>
          <Field label="운영시간">
            <input
              value={openingHours}
              onChange={(e) => setOpeningHours(e.target.value)}
              placeholder="예) 매일 08:00 - 22:00"
              className="input-base"
            />
          </Field>
        </div>

        <Field label="소개글">
          <textarea
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            placeholder="이 맛집을 소개해주세요"
            className="input-base rounded-2xl"
          />
        </Field>

        <Field label="추천 이유">
          <textarea
            value={recommendReason}
            onChange={(e) => setRecommendReason(e.target.value)}
            rows={3}
            placeholder="왜 이 맛집을 추천하고 싶나요?"
            className="input-base rounded-2xl"
          />
        </Field>

        <button disabled={submitting} type="submit" className="btn-primary mt-2">
          {submitting ? "등록 중..." : "맛집 등록 완료"}
        </button>
      </form>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-semibold text-accent-brown">
        {label}
      </label>
      {children}
    </div>
  );
}
