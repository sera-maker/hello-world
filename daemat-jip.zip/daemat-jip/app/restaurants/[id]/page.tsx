"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { doc, onSnapshot, deleteDoc, updateDoc, increment } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Restaurant } from "@/types";
import { useAuth } from "@/hooks/useAuth";
import MapView from "@/components/MapView";
import CommentSection from "@/components/CommentSection";
import LikeButton from "@/components/LikeButton";
import ShareButton from "@/components/ShareButton";
import ScrollReveal from "@/components/ScrollReveal";
import { Clock, Tag, MapPin, Trash2, Bookmark } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function RestaurantDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { user, appUser, isAdmin, toggleFavorite } = useAuth();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [activeImage, setActiveImage] = useState(0);
  const viewCounted = useState(() => ({ done: false }))[0];

  useEffect(() => {
    if (!id) return;
    const ref = doc(db, "restaurants", id);
    const unsub = onSnapshot(ref, (snap) => {
      if (!snap.exists()) {
        setNotFound(true);
        return;
      }
      setRestaurant({ id: snap.id, ...snap.data() } as Restaurant);
      if (!viewCounted.done) {
        viewCounted.done = true;
        updateDoc(ref, { viewCount: increment(1) }).catch(() => {});
      }
    });
    return () => unsub();
  }, [id, viewCounted]);

  if (notFound) {
    return (
      <div className="py-24 text-center text-accent-brown/60">
        존재하지 않는 맛집이에요.
      </div>
    );
  }

  if (!restaurant) {
    return <div className="py-24 text-center text-accent-brown/40">불러오는 중...</div>;
  }

  const isFavorited = appUser?.favorites.includes(restaurant.id) ?? false;

  const handleDelete = async () => {
    if (!confirm("이 게시글을 삭제하시겠어요? 이 작업은 되돌릴 수 없어요.")) return;
    await deleteDoc(doc(db, "restaurants", restaurant.id));
    router.push("/");
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="relative h-72 w-full overflow-hidden rounded-xl3 bg-brand-100 sm:h-96">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeImage}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0"
          >
            {restaurant.images[activeImage] ? (
              <Image
                src={restaurant.images[activeImage]}
                alt={restaurant.name}
                fill
                className="object-cover"
                priority
              />
            ) : (
              <div className="flex h-full items-center justify-center text-6xl">🍽️</div>
            )}
          </motion.div>
        </AnimatePresence>

        {restaurant.images.length > 1 && (
          <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-1.5">
            {restaurant.images.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveImage(i)}
                className={`h-2 w-2 rounded-full transition-all ${
                  i === activeImage ? "w-5 bg-white" : "bg-white/50"
                }`}
              />
            ))}
          </div>
        )}
      </div>

      <div className="mt-6 flex items-start justify-between">
        <div>
          <span className="rounded-full bg-brand-100 px-3 py-1 text-xs font-semibold text-accent-brown">
            {restaurant.category}
          </span>
          <h1 className="mt-2 text-2xl font-extrabold text-accent-brown">
            {restaurant.name}
          </h1>
          <p className="mt-1 flex items-center gap-1 text-sm text-accent-brown/60">
            <MapPin className="h-4 w-4" /> {restaurant.address}
          </p>
        </div>
        {user && (
          <button
            onClick={() => toggleFavorite(restaurant.id)}
            className="rounded-full p-2 hover:bg-brand-100"
            title="즐겨찾기"
          >
            <Bookmark
              className={`h-6 w-6 ${
                isFavorited ? "fill-brand-500 text-brand-500" : "text-accent-brown/40"
              }`}
            />
          </button>
        )}
      </div>

      <div className="mt-5 flex flex-wrap gap-3">
        <LikeButton restaurantId={restaurant.id} likeCount={restaurant.likeCount} />
        <ShareButton title={restaurant.name} />
        {isAdmin && (
          <button
            onClick={handleDelete}
            className="flex items-center gap-2 rounded-full border-2 border-red-200 bg-red-50 px-5 py-2.5 font-semibold text-red-500"
          >
            <Trash2 className="h-4 w-4" /> 게시글 삭제
          </button>
        )}
      </div>

      <ScrollReveal className="mt-8">
        <h2 className="mb-2 text-lg font-bold text-accent-brown">소개</h2>
        <p className="whitespace-pre-line leading-relaxed text-accent-brown/80">
          {restaurant.description}
        </p>
        {restaurant.recommendReason && (
          <div className="mt-4 rounded-xl2 bg-brand-50 p-4 text-sm text-accent-brown/80">
            💛 <strong>추천 이유</strong>
            <p className="mt-1">{restaurant.recommendReason}</p>
          </div>
        )}
      </ScrollReveal>

      <ScrollReveal className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <InfoBox icon={<Tag className="h-4 w-4" />} label="대표 메뉴" value={restaurant.menu} />
        <InfoBox icon={<Tag className="h-4 w-4" />} label="가격대" value={restaurant.priceRange || "정보 없음"} />
        <InfoBox
          icon={<Clock className="h-4 w-4" />}
          label="운영시간"
          value={restaurant.openingHours || "정보 없음"}
        />
        <InfoBox
          icon={<MapPin className="h-4 w-4" />}
          label="등록자"
          value={restaurant.authorName}
        />
      </ScrollReveal>

      <ScrollReveal className="mt-8">
        <h2 className="mb-3 text-lg font-bold text-accent-brown">위치</h2>
        <MapView restaurants={[restaurant]} center={restaurant.location} height="320px" />
      </ScrollReveal>

      <ScrollReveal className="mt-10 border-t border-brand-100 pt-8">
        <CommentSection restaurantId={restaurant.id} />
      </ScrollReveal>
    </div>
  );
}

function InfoBox({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl2 bg-white p-4 shadow-soft">
      <div className="flex items-center gap-1.5 text-xs font-semibold text-accent-brown/50">
        {icon} {label}
      </div>
      <p className="mt-1 font-semibold text-accent-brown">{value}</p>
    </div>
  );
}
