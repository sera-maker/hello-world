"use client";

import { CATEGORIES, Category } from "@/types";
import { cn } from "@/lib/utils";

const ICONS: Record<Category, string> = {
  한식: "🍚",
  중식: "🥟",
  일식: "🍣",
  양식: "🍝",
  카페: "☕",
  디저트: "🍰",
  술집: "🍻",
  분식: "🍢",
  치킨: "🍗",
  패스트푸드: "🍔",
  기타: "🍽️",
};

interface Props {
  value: Category | "전체";
  onChange: (category: Category | "전체") => void;
}

export default function CategoryFilter({ value, onChange }: Props) {
  const all: (Category | "전체")[] = ["전체", ...CATEGORIES];

  return (
    <div className="flex gap-2 overflow-x-auto px-4 pb-2 scrollbar-none">
      {all.map((c) => (
        <button
          key={c}
          onClick={() => onChange(c)}
          className={cn(
            "flex shrink-0 items-center gap-1.5 rounded-full border px-4 py-2 text-sm font-medium transition-all duration-300",
            value === c
              ? "border-brand-500 bg-brand-500 text-white shadow-card"
              : "border-brand-200 bg-white text-accent-brown hover:bg-brand-100"
          )}
        >
          <span>{c === "전체" ? "🍽️" : ICONS[c as Category]}</span>
          {c}
        </button>
      ))}
    </div>
  );
}
