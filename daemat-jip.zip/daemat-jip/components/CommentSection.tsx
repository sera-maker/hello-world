"use client";

import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useComments } from "@/hooks/useComments";
import { formatRelativeTime } from "@/lib/utils";
import { Comment } from "@/types";
import { Trash2, CornerDownRight } from "lucide-react";

export default function CommentSection({ restaurantId }: { restaurantId: string }) {
  const { user, appUser, isAdmin } = useAuth();
  const { comments, addComment, deleteComment } = useComments(restaurantId);
  const [content, setContent] = useState("");
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState("");

  const topLevel = comments.filter((c) => !c.parentId);
  const repliesOf = (id: string) => comments.filter((c) => c.parentId === id);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !appUser || !content.trim()) return;
    await addComment({
      content: content.trim(),
      authorId: user.uid,
      authorName: appUser.displayName,
      authorPhotoURL: appUser.photoURL,
    });
    setContent("");
  };

  const submitReply = async (parentId: string) => {
    if (!user || !appUser || !replyContent.trim()) return;
    await addComment({
      content: replyContent.trim(),
      parentId,
      authorId: user.uid,
      authorName: appUser.displayName,
      authorPhotoURL: appUser.photoURL,
    });
    setReplyContent("");
    setReplyTo(null);
  };

  const renderComment = (c: Comment, isReply = false) => (
    <div key={c.id} className={isReply ? "ml-8 mt-3" : "border-b border-brand-100 pb-4"}>
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-sm font-semibold text-accent-brown">{c.authorName}</p>
          <p className="mt-1 text-sm text-accent-brown/80">{c.content}</p>
          <div className="mt-1 flex items-center gap-3 text-xs text-accent-brown/40">
            <span>{formatRelativeTime(c.createdAt)}</span>
            {!isReply && user && (
              <button
                className="flex items-center gap-1 font-medium text-accent-orange"
                onClick={() => setReplyTo(replyTo === c.id ? null : c.id)}
              >
                <CornerDownRight className="h-3 w-3" /> 답글
              </button>
            )}
          </div>
        </div>
        {(user?.uid === c.authorId || isAdmin) && (
          <button
            onClick={() => deleteComment(c.id)}
            className="text-accent-brown/30 hover:text-red-500"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        )}
      </div>

      {replyTo === c.id && (
        <div className="ml-8 mt-2 flex gap-2">
          <input
            value={replyContent}
            onChange={(e) => setReplyContent(e.target.value)}
            placeholder="답글을 입력하세요"
            className="input-base flex-1 text-sm"
          />
          <button
            onClick={() => submitReply(c.id)}
            className="btn-primary px-4 py-2 text-sm"
          >
            등록
          </button>
        </div>
      )}

      {repliesOf(c.id).map((r) => renderComment(r, true))}
    </div>
  );

  return (
    <div>
      <h3 className="mb-4 text-lg font-bold text-accent-brown">
        댓글 {comments.length}
      </h3>

      {user ? (
        <form onSubmit={submit} className="mb-6 flex gap-2">
          <input
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="따뜻한 댓글을 남겨보세요"
            className="input-base flex-1"
          />
          <button type="submit" className="btn-primary px-5">
            등록
          </button>
        </form>
      ) : (
        <p className="mb-6 rounded-xl2 bg-brand-50 p-4 text-sm text-accent-brown/60">
          댓글을 작성하려면 로그인이 필요해요.
        </p>
      )}

      <div className="flex flex-col gap-4">
        {topLevel.length === 0 ? (
          <p className="py-8 text-center text-sm text-accent-brown/40">
            아직 댓글이 없어요. 첫 댓글을 남겨보세요!
          </p>
        ) : (
          topLevel.map((c) => renderComment(c))
        )}
      </div>
    </div>
  );
}
