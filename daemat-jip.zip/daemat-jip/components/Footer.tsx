export default function Footer() {
  return (
    <footer className="mt-16 border-t border-brand-100 bg-cream px-4 py-10 text-center text-sm text-accent-brown/60">
      <p className="mb-1 text-lg font-bold text-accent-brown">🍽️ 대맛집</p>
      <p>대전 시민과 관광객이 함께 만드는 맛집 공유 플랫폼</p>
      <p className="mt-3">
        © {new Date().getFullYear()} 대맛집. 문의: contact@daemat-jip.example.com
      </p>
    </footer>
  );
}
