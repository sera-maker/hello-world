"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Search, Menu, X, MapPin, Heart, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import LoginModal from "./LoginModal";

export default function Header() {
  const { user, appUser, signOut } = useAuth();
  const [showLogin, setShowLogin] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [term, setTerm] = useState("");
  const router = useRouter();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    router.push(`/?q=${encodeURIComponent(term)}`);
  };

  return (
    <>
      <header className="sticky top-0 z-40 glass shadow-soft">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3">
          <Link href="/" className="flex shrink-0 items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-500 text-lg">
              🍽️
            </span>
            <span className="text-xl font-extrabold text-accent-brown">
              대맛집
            </span>
          </Link>

          <form
            onSubmit={handleSearch}
            className="hidden flex-1 items-center md:flex"
          >
            <div className="relative w-full max-w-md">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-accent-brown/50" />
              <input
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                placeholder="맛집, 지역, 메뉴로 검색해보세요"
                className="input-base pl-10"
              />
            </div>
          </form>

          <nav className="hidden items-center gap-3 md:flex">
            <Link
              href="/register"
              className="rounded-full px-4 py-2 text-sm font-semibold text-accent-brown hover:bg-brand-100"
            >
              맛집 등록하기
            </Link>
            {user ? (
              <div className="flex items-center gap-2">
                <Link
                  href="/favorites"
                  title="즐겨찾기"
                  className="rounded-full p-2 hover:bg-brand-100"
                >
                  <Heart className="h-5 w-5 text-accent-brown" />
                </Link>
                <Link href="/mypage" className="flex items-center gap-2">
                  {appUser?.photoURL ? (
                    <Image
                      src={appUser.photoURL}
                      alt={appUser.displayName}
                      width={32}
                      height={32}
                      className="rounded-full"
                    />
                  ) : (
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-300 text-sm font-bold">
                      {appUser?.displayName?.[0] ?? "U"}
                    </span>
                  )}
                </Link>
                <button
                  onClick={() => signOut()}
                  title="로그아웃"
                  className="rounded-full p-2 hover:bg-brand-100"
                >
                  <LogOut className="h-4 w-4 text-accent-brown" />
                </button>
              </div>
            ) : (
              <button onClick={() => setShowLogin(true)} className="btn-primary">
                로그인
              </button>
            )}
          </nav>

          <button
            className="ml-auto p-2 md:hidden"
            onClick={() => setMenuOpen((v) => !v)}
          >
            {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {menuOpen && (
          <div className="border-t border-brand-100 bg-white/95 px-4 py-4 md:hidden">
            <form onSubmit={handleSearch} className="mb-3">
              <div className="relative">
                <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-accent-brown/50" />
                <input
                  value={term}
                  onChange={(e) => setTerm(e.target.value)}
                  placeholder="맛집, 지역, 메뉴로 검색"
                  className="input-base pl-10"
                />
              </div>
            </form>
            <div className="flex flex-col gap-2">
              <Link
                href="/register"
                className="rounded-full bg-brand-100 px-4 py-2 text-center font-semibold text-accent-brown"
              >
                <MapPin className="mr-1 inline h-4 w-4" /> 맛집 등록하기
              </Link>
              {user ? (
                <>
                  <Link
                    href="/favorites"
                    className="rounded-full px-4 py-2 text-center"
                  >
                    즐겨찾기
                  </Link>
                  <Link href="/mypage" className="rounded-full px-4 py-2 text-center">
                    마이페이지
                  </Link>
                  <button
                    onClick={() => signOut()}
                    className="rounded-full px-4 py-2 text-center text-red-500"
                  >
                    로그아웃
                  </button>
                </>
              ) : (
                <button onClick={() => setShowLogin(true)} className="btn-primary">
                  로그인
                </button>
              )}
            </div>
          </div>
        )}
      </header>
      <LoginModal open={showLogin} onClose={() => setShowLogin(false)} />
    </>
  );
}
