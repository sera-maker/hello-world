"use client";

import Link from "next/link";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-brand-100 via-brand-50 to-cream px-4 py-20 text-center">
      <motion.span
        className="absolute left-8 top-10 text-5xl animate-floatSlow"
        aria-hidden
      >
        🍜
      </motion.span>
      <motion.span
        className="absolute right-10 top-24 text-4xl animate-floatSlow"
        style={{ animationDelay: "1.5s" }}
        aria-hidden
      >
        🍩
      </motion.span>
      <motion.span
        className="absolute bottom-8 left-1/4 text-4xl animate-floatSlow"
        style={{ animationDelay: "3s" }}
        aria-hidden
      >
        🍗
      </motion.span>
      <motion.span
        className="absolute bottom-16 right-1/4 text-5xl animate-floatSlow"
        style={{ animationDelay: "2s" }}
        aria-hidden
      >
        ☕
      </motion.span>

      <motion.h1
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="relative mx-auto max-w-2xl text-3xl font-extrabold leading-snug text-accent-brown sm:text-4xl md:text-5xl"
      >
        대전의 숨은 맛집을
        <br />
        <span className="text-brand-600">공유해보세요</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.15 }}
        className="relative mx-auto mt-4 max-w-md text-accent-brown/70"
      >
        여행하듯 대전을 맛보다. 시민과 관광객이 함께 만드는
        살아있는 맛집 지도, 대맛집과 함께해요.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.3 }}
        className="relative mt-8 flex flex-wrap items-center justify-center gap-3"
      >
        <Link href="/register" className="btn-primary">
          맛집 등록하기
        </Link>
        <Link href="#restaurants" className="btn-secondary">
          맛집 둘러보기
        </Link>
      </motion.div>
    </section>
  );
}
