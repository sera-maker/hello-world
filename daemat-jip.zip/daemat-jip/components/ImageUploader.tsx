"use client";

import { useState } from "react";
import Image from "next/image";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { storage } from "@/lib/firebase";
import { ImagePlus, X, Loader2 } from "lucide-react";

interface Props {
  images: string[];
  onChange: (urls: string[]) => void;
  userId: string;
  max?: number;
}

export default function ImageUploader({
  images,
  onChange,
  userId,
  max = 5,
}: Props) {
  const [uploading, setUploading] = useState(false);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const remaining = max - images.length;
    const list = Array.from(files).slice(0, remaining);

    setUploading(true);
    try {
      const urls = await Promise.all(
        list.map(async (file) => {
          const path = `restaurants/${userId}/${Date.now()}-${file.name}`;
          const storageRef = ref(storage, path);
          await uploadBytes(storageRef, file);
          return getDownloadURL(storageRef);
        })
      );
      onChange([...images, ...urls]);
    } catch (err) {
      console.error("이미지 업로드 실패:", err);
      alert("이미지 업로드에 실패했습니다. 다시 시도해주세요.");
    } finally {
      setUploading(false);
    }
  };

  const removeImage = (url: string) => {
    onChange(images.filter((u) => u !== url));
  };

  return (
    <div>
      <div className="flex flex-wrap gap-3">
        {images.map((url) => (
          <div
            key={url}
            className="relative h-24 w-24 overflow-hidden rounded-xl2 shadow-soft"
          >
            <Image src={url} alt="업로드 이미지" fill className="object-cover" />
            <button
              type="button"
              onClick={() => removeImage(url)}
              className="absolute right-1 top-1 rounded-full bg-black/50 p-1 text-white"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        ))}

        {images.length < max && (
          <label className="flex h-24 w-24 cursor-pointer flex-col items-center justify-center gap-1 rounded-xl2 border-2 border-dashed border-brand-300 bg-brand-50 text-accent-brown/60 transition hover:bg-brand-100">
            {uploading ? (
              <Loader2 className="h-6 w-6 animate-spin" />
            ) : (
              <>
                <ImagePlus className="h-6 w-6" />
                <span className="text-xs">사진 추가</span>
              </>
            )}
            <input
              type="file"
              accept="image/*"
              multiple
              hidden
              disabled={uploading}
              onChange={(e) => handleFiles(e.target.files)}
            />
          </label>
        )}
      </div>
      <p className="mt-2 text-xs text-accent-brown/50">
        최대 {max}장까지 업로드할 수 있어요. ({images.length}/{max})
      </p>
    </div>
  );
}
