"use client";

import { motion } from "framer-motion";
import { Heart } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useLikes } from "@/hooks/useLikes";
import { cn } from "@/lib/utils";

export default function LikeButton({
  restaurantId,
  likeCount,
}: {
  restaurantId: string;
  likeCount: number;
}) {
  const { user } = useAuth();
  const { liked, toggleLike } = useLikes(restaurantId, user?.uid);

  return (
    <motion.button
      whileTap={{ scale: 0.85 }}
      onClick={() => {
        if (!user) {
          alert("로그인이 필요한 기능이에요.");
          return;
        }
        toggleLike();
      }}
      className={cn(
        "flex items-center gap-2 rounded-full border-2 px-5 py-2.5 font-semibold transition-all",
        liked
          ? "border-red-400 bg-red-50 text-red-500"
          : "border-brand-200 bg-white text-accent-brown hover:bg-brand-50"
      )}
    >
      <Heart className={cn("h-4 w-4", liked && "fill-red-500")} />
      좋아요 {likeCount}
    </motion.button>
  );
}
