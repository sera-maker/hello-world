"use client";

import { useEffect, useRef, useState } from "react";
import Script from "next/script";
import { RestaurantLocation } from "@/types";

declare global {
  interface Window {
    kakao: any;
  }
}

interface Props {
  value: RestaurantLocation | null;
  onChange: (loc: RestaurantLocation) => void;
}

const DAEJEON_CENTER = { lat: 36.3504, lng: 127.3845 };

export default function LocationPicker({ value, onChange }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markerInstance = useRef<any>(null);
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const kakaoKey = process.env.NEXT_PUBLIC_KAKAO_MAP_API_KEY;

  useEffect(() => {
    if (!scriptLoaded || !mapRef.current || !window.kakao) return;

    window.kakao.maps.load(() => {
      const center = value || DAEJEON_CENTER;
      const map = new window.kakao.maps.Map(mapRef.current, {
        center: new window.kakao.maps.LatLng(center.lat, center.lng),
        level: 5,
      });
      mapInstance.current = map;

      const marker = new window.kakao.maps.Marker({
        position: new window.kakao.maps.LatLng(center.lat, center.lng),
        map,
      });
      markerInstance.current = marker;

      window.kakao.maps.event.addListener(
        map,
        "click",
        (e: { latLng: { getLat: () => number; getLng: () => number } }) => {
          const lat = e.latLng.getLat();
          const lng = e.latLng.getLng();
          marker.setPosition(e.latLng);
          onChange({ lat, lng });
        }
      );
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scriptLoaded]);

  if (!kakaoKey) {
    return (
      <div className="rounded-xl2 bg-brand-50 p-4 text-sm text-accent-brown/60">
        🗺️ 카카오맵 API 키가 없어서 지도를 표시할 수 없어요. 위도/경도를 직접
        입력해주세요.
        <div className="mt-3 flex gap-2">
          <input
            type="number"
            step="any"
            placeholder="위도 (lat)"
            className="input-base"
            value={value?.lat ?? ""}
            onChange={(e) =>
              onChange({ lat: Number(e.target.value), lng: value?.lng ?? 0 })
            }
          />
          <input
            type="number"
            step="any"
            placeholder="경도 (lng)"
            className="input-base"
            value={value?.lng ?? ""}
            onChange={(e) =>
              onChange({ lat: value?.lat ?? 0, lng: Number(e.target.value) })
            }
          />
        </div>
      </div>
    );
  }

  return (
    <div>
      <Script
        src={`//dapi.kakao.com/v2/maps/sdk.js?appkey=${kakaoKey}&autoload=false`}
        onLoad={() => setScriptLoaded(true)}
      />
      <div
        ref={mapRef}
        style={{ height: "280px", width: "100%" }}
        className="rounded-xl2"
      />
      <p className="mt-2 text-xs text-accent-brown/50">
        지도를 클릭해서 맛집의 정확한 위치를 지정해주세요.
        {value && ` (선택됨: ${value.lat.toFixed(5)}, ${value.lng.toFixed(5)})`}
      </p>
    </div>
  );
}
