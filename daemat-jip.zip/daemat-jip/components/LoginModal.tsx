"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Mail, Lock, User as UserIcon } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function LoginModal({ open, onClose }: Props) {
  const { signInWithGoogle, signInWithEmail, signUpWithEmail } = useAuth();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      if (mode === "login") {
        await signInWithEmail(email, password);
      } else {
        await signUpWithEmail(email, password, name);
      }
      onClose();
    } catch (err: any) {
      setError("로그인에 실패했습니다. 이메일과 비밀번호를 확인해주세요.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="glass w-full max-w-sm rounded-xl3 bg-cream p-8 shadow-card-hover"
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.96 }}
            transition={{ type: "spring", damping: 20, stiffness: 260 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-xl font-bold text-accent-brown">
                {mode === "login" ? "로그인" : "회원가입"}
              </h2>
              <button onClick={onClose}>
                <X className="h-5 w-5" />
              </button>
            </div>

            <button
              onClick={() => signInWithGoogle().then(onClose)}
              className="mb-4 flex w-full items-center justify-center gap-2 rounded-full border border-brand-200 bg-white py-3 font-semibold shadow-soft transition hover:bg-brand-50"
            >
              <span>🔍</span> Google로 계속하기
            </button>

            <div className="mb-4 flex items-center gap-3 text-xs text-accent-brown/50">
              <div className="h-px flex-1 bg-brand-200" />
              또는 이메일로 계속하기
              <div className="h-px flex-1 bg-brand-200" />
            </div>

            <form onSubmit={handleSubmit} className="flex flex-col gap-3">
              {mode === "signup" && (
                <div className="relative">
                  <UserIcon className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-accent-brown/40" />
                  <input
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="닉네임"
                    className="input-base pl-10"
                  />
                </div>
              )}
              <div className="relative">
                <Mail className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-accent-brown/40" />
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="이메일"
                  className="input-base pl-10"
                />
              </div>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-accent-brown/40" />
                <input
                  required
                  type="password"
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="비밀번호 (6자 이상)"
                  className="input-base pl-10"
                />
              </div>

              {error && <p className="text-sm text-red-500">{error}</p>}

              <button disabled={loading} type="submit" className="btn-primary mt-2">
                {loading ? "처리 중..." : mode === "login" ? "로그인" : "회원가입"}
              </button>
            </form>

            <p className="mt-5 text-center text-sm text-accent-brown/70">
              {mode === "login" ? (
                <>
                  아직 계정이 없으신가요?{" "}
                  <button
                    className="font-semibold text-accent-orange"
                    onClick={() => setMode("signup")}
                  >
                    회원가입
                  </button>
                </>
              ) : (
                <>
                  이미 계정이 있으신가요?{" "}
                  <button
                    className="font-semibold text-accent-orange"
                    onClick={() => setMode("login")}
                  >
                    로그인
                  </button>
                </>
              )}
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
