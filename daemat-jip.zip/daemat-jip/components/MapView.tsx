"use client";

import { useEffect, useRef, useState } from "react";
import Script from "next/script";
import Link from "next/link";
import { Restaurant } from "@/types";

declare global {
  interface Window {
    kakao: any;
  }
}

interface Props {
  restaurants: Restaurant[];
  /** 단일 맛집 상세 페이지에서 쓸 경우 지정 (지도 중심 이동용) */
  center?: { lat: number; lng: number };
  height?: string;
}

export default function MapView({ restaurants, center, height = "420px" }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const [selected, setSelected] = useState<Restaurant | null>(null);
  const kakaoKey = process.env.NEXT_PUBLIC_KAKAO_MAP_API_KEY;

  useEffect(() => {
    if (!scriptLoaded || !mapRef.current || !window.kakao) return;

    window.kakao.maps.load(() => {
      const defaultCenter =
        center ||
        (restaurants[0]?.location ?? { lat: 36.3504, lng: 127.3845 }); // 대전시청 기본 좌표

      const map = new window.kakao.maps.Map(mapRef.current, {
        center: new window.kakao.maps.LatLng(
          defaultCenter.lat,
          defaultCenter.lng
        ),
        level: 6,
      });

      restaurants.forEach((r) => {
        if (!r.location) return;
        const marker = new window.kakao.maps.Marker({
          position: new window.kakao.maps.LatLng(r.location.lat, r.location.lng),
          map,
        });
        window.kakao.maps.event.addListener(marker, "click", () => {
          setSelected(r);
          map.panTo(marker.getPosition());
        });
      });
    });
  }, [scriptLoaded, restaurants, center]);

  if (!kakaoKey) {
    return (
      <div
        style={{ height }}
        className="flex flex-col items-center justify-center gap-2 rounded-xl2 bg-brand-50 text-center text-sm text-accent-brown/60"
      >
        <p>🗺️ 카카오맵 API 키가 설정되지 않았습니다.</p>
        <p>.env.local에 NEXT_PUBLIC_KAKAO_MAP_API_KEY를 추가해주세요.</p>
      </div>
    );
  }

  return (
    <div className="relative">
      <Script
        src={`//dapi.kakao.com/v2/maps/sdk.js?appkey=${kakaoKey}&autoload=false`}
        onLoad={() => setScriptLoaded(true)}
      />
      <div ref={mapRef} style={{ height, width: "100%" }} className="rounded-xl2" />

      {selected && (
        <div className="absolute bottom-4 left-1/2 w-[90%] max-w-sm -translate-x-1/2 rounded-xl2 bg-white p-4 shadow-card-hover">
          <button
            className="absolute right-3 top-3 text-accent-brown/50"
            onClick={() => setSelected(null)}
          >
            ✕
          </button>
          <div className="flex gap-3">
            <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-brand-100 text-2xl">
              {selected.images?.[0] ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={selected.images[0]}
                  alt={selected.name}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full items-center justify-center">🍽️</div>
              )}
            </div>
            <div className="min-w-0">
              <p className="truncate font-bold text-accent-brown">
                {selected.name}
              </p>
              <p className="truncate text-xs text-accent-brown/60">
                {selected.address}
              </p>
              <p className="mt-1 line-clamp-2 text-xs text-accent-brown/70">
                {selected.description}
              </p>
              <Link
                href={`/restaurants/${selected.id}`}
                className="mt-2 inline-block text-xs font-semibold text-accent-orange"
              >
                자세히 보기 →
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
