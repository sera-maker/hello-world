"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Heart, MessageCircle, MapPin } from "lucide-react";
import { Restaurant } from "@/types";

export default function RestaurantCard({
  restaurant,
  index = 0,
}: {
  restaurant: Restaurant;
  index?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, delay: (index % 8) * 0.05 }}
      whileHover={{ scale: 1.02 }}
    >
      <Link
        href={`/restaurants/${restaurant.id}`}
        className="card-base group block overflow-hidden"
      >
        <div className="relative h-44 w-full overflow-hidden bg-brand-100">
          {restaurant.images?.[0] ? (
            <Image
              src={restaurant.images[0]}
              alt={restaurant.name}
              fill
              sizes="(max-width: 768px) 100vw, 25vw"
              className="object-cover transition-transform duration-500 group-hover:scale-110"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-4xl">
              🍽️
            </div>
          )}
          <span className="absolute left-3 top-3 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-accent-brown shadow-soft">
            {restaurant.category}
          </span>
        </div>

        <div className="p-4">
          <h3 className="truncate text-base font-bold text-accent-brown">
            {restaurant.name}
          </h3>
          <p className="mt-1 flex items-center gap-1 truncate text-xs text-accent-brown/60">
            <MapPin className="h-3 w-3 shrink-0" />
            {restaurant.address}
          </p>

          <div className="mt-3 flex items-center justify-between">
            <span className="text-xs text-accent-brown/50">
              {restaurant.authorName}
            </span>
            <div className="flex items-center gap-3 text-xs text-accent-brown/70">
              <span className="flex items-center gap-1">
                <Heart className="h-3.5 w-3.5" /> {restaurant.likeCount ?? 0}
              </span>
              <span className="flex items-center gap-1">
                <MessageCircle className="h-3.5 w-3.5" />{" "}
                {restaurant.commentCount ?? 0}
              </span>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
