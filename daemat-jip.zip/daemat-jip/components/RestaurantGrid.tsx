"use client";

import { Restaurant } from "@/types";
import RestaurantCard from "./RestaurantCard";

export default function RestaurantGrid({
  restaurants,
  loading,
}: {
  restaurants: Restaurant[];
  loading: boolean;
}) {
  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-4 px-4 sm:grid-cols-3 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="h-64 animate-pulse rounded-xl2 bg-brand-100/70"
          />
        ))}
      </div>
    );
  }

  if (restaurants.length === 0) {
    return (
      <div className="flex flex-col items-center gap-3 px-4 py-20 text-center text-accent-brown/60">
        <span className="text-5xl">🔍</span>
        <p>조건에 맞는 맛집이 아직 없어요.</p>
        <p className="text-sm">첫 번째로 맛집을 등록해보세요!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 px-4 sm:grid-cols-3 lg:grid-cols-4">
      {restaurants.map((r, i) => (
        <RestaurantCard key={r.id} restaurant={r} index={i} />
      ))}
    </div>
  );
}
