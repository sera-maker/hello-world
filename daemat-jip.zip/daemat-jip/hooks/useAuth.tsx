"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";
import {
  onAuthStateChanged,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut as firebaseSignOut,
  User,
} from "firebase/auth";
import {
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
  arrayUnion,
  arrayRemove,
  updateDoc,
} from "firebase/firestore";
import { auth, googleProvider, db } from "@/lib/firebase";
import { AppUser } from "@/types";
import { isAdminEmail } from "@/lib/utils";

interface AuthContextValue {
  user: User | null;
  appUser: AppUser | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (
    email: string,
    password: string,
    displayName: string
  ) => Promise<void>;
  signOut: () => Promise<void>;
  toggleFavorite: (restaurantId: string) => Promise<void>;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function ensureUserDoc(user: User): Promise<AppUser> {
  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);
  if (snap.exists()) {
    return snap.data() as AppUser;
  }
  const newUser: AppUser = {
    uid: user.uid,
    displayName: user.displayName || "익명 사용자",
    email: user.email || "",
    photoURL: user.photoURL || undefined,
    role: isAdminEmail(user.email) ? "admin" : "user",
    favorites: [],
    createdAt: serverTimestamp() as any,
  };
  await setDoc(ref, newUser);
  return newUser;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [appUser, setAppUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        const profile = await ensureUserDoc(firebaseUser);
        setAppUser(profile);
      } else {
        setAppUser(null);
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const signInWithGoogle = async () => {
    await signInWithPopup(auth, googleProvider);
  };

  const signInWithEmail = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email, password);
  };

  const signUpWithEmail = async (
    email: string,
    password: string,
    displayName: string
  ) => {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(cred.user, { displayName });
    await ensureUserDoc(cred.user);
  };

  const signOut = async () => {
    await firebaseSignOut(auth);
  };

  const toggleFavorite = async (restaurantId: string) => {
    if (!user || !appUser) return;
    const ref = doc(db, "users", user.uid);
    const isFav = appUser.favorites.includes(restaurantId);
    await updateDoc(ref, {
      favorites: isFav
        ? arrayRemove(restaurantId)
        : arrayUnion(restaurantId),
    });
    setAppUser({
      ...appUser,
      favorites: isFav
        ? appUser.favorites.filter((id) => id !== restaurantId)
        : [...appUser.favorites, restaurantId],
    });
  };

  const isAdmin = appUser?.role === "admin";

  return (
    <AuthContext.Provider
      value={{
        user,
        appUser,
        loading,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        signOut,
        toggleFavorite,
        isAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth는 AuthProvider 내부에서 사용해야 합니다.");
  return ctx;
}
