"use client";

import { useEffect, useState } from "react";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  increment,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Comment } from "@/types";

export function useComments(restaurantId: string) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!restaurantId) return;
    const q = query(
      collection(db, "comments"),
      where("restaurantId", "==", restaurantId),
      orderBy("createdAt", "asc")
    );
    const unsub = onSnapshot(q, (snap) => {
      setComments(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Comment)));
      setLoading(false);
    });
    return () => unsub();
  }, [restaurantId]);

  const addComment = async (params: {
    content: string;
    parentId?: string | null;
    authorId: string;
    authorName: string;
    authorPhotoURL?: string;
  }) => {
    await addDoc(collection(db, "comments"), {
      restaurantId,
      parentId: params.parentId || null,
      content: params.content,
      authorId: params.authorId,
      authorName: params.authorName,
      authorPhotoURL: params.authorPhotoURL || null,
      createdAt: serverTimestamp(),
    });
    await updateDoc(doc(db, "restaurants", restaurantId), {
      commentCount: increment(1),
    });
  };

  const deleteComment = async (commentId: string) => {
    await deleteDoc(doc(db, "comments", commentId));
    await updateDoc(doc(db, "restaurants", restaurantId), {
      commentCount: increment(-1),
    });
  };

  return { comments, loading, addComment, deleteComment };
}
