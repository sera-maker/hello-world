"use client";

import { useEffect, useState } from "react";
import {
  deleteDoc,
  doc,
  getDoc,
  increment,
  setDoc,
  updateDoc,
} from "firebase/firestore";
import { db } from "@/lib/firebase";

export function useLikes(restaurantId: string, userId: string | undefined) {
  const [liked, setLiked] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    if (!restaurantId || !userId) {
      setChecking(false);
      return;
    }
    const likeRef = doc(db, "restaurants", restaurantId, "likes", userId);
    getDoc(likeRef).then((snap) => {
      setLiked(snap.exists());
      setChecking(false);
    });
  }, [restaurantId, userId]);

  const toggleLike = async () => {
    if (!userId) return;
    const likeRef = doc(db, "restaurants", restaurantId, "likes", userId);
    const restaurantRef = doc(db, "restaurants", restaurantId);

    if (liked) {
      await deleteDoc(likeRef);
      await updateDoc(restaurantRef, { likeCount: increment(-1) });
      setLiked(false);
    } else {
      await setDoc(likeRef, { userId, createdAt: Date.now() });
      await updateDoc(restaurantRef, { likeCount: increment(1) });
      setLiked(true);
    }
  };

  return { liked, checking, toggleLike };
}
