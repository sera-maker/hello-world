"use client";

import { useEffect, useMemo, useState } from "react";
import {
  collection,
  onSnapshot,
  orderBy,
  query,
  where,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Category, Restaurant } from "@/types";

interface UseRestaurantsOptions {
  category?: Category | "전체";
  searchTerm?: string;
}

export function useRestaurants({
  category = "전체",
  searchTerm = "",
}: UseRestaurantsOptions = {}) {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const base = collection(db, "restaurants");
    const q =
      category === "전체"
        ? query(base, orderBy("createdAt", "desc"))
        : query(
            base,
            where("category", "==", category),
            orderBy("createdAt", "desc")
          );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const data = snap.docs.map(
          (d) => ({ id: d.id, ...d.data() } as Restaurant)
        );
        setRestaurants(data);
        setLoading(false);
      },
      (err) => {
        console.error("맛집 목록을 불러오지 못했습니다:", err);
        setLoading(false);
      }
    );
    return () => unsub();
  }, [category]);

  const filtered = useMemo(() => {
    if (!searchTerm.trim()) return restaurants;
    const term = searchTerm.trim().toLowerCase();
    return restaurants.filter((r) =>
      [r.name, r.address, r.menu, r.description]
        .join(" ")
        .toLowerCase()
        .includes(term)
    );
  }, [restaurants, searchTerm]);

  return { restaurants: filtered, loading };
}
