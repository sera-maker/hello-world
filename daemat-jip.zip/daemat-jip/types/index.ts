import { Timestamp } from "firebase/firestore";

export type Category =
  | "한식"
  | "중식"
  | "일식"
  | "양식"
  | "카페"
  | "디저트"
  | "술집"
  | "분식"
  | "치킨"
  | "패스트푸드"
  | "기타";

export const CATEGORIES: Category[] = [
  "한식",
  "중식",
  "일식",
  "양식",
  "카페",
  "디저트",
  "술집",
  "분식",
  "치킨",
  "패스트푸드",
  "기타",
];

export interface RestaurantLocation {
  lat: number;
  lng: number;
}

export interface Restaurant {
  id: string;
  name: string;
  category: Category;
  address: string;
  location: RestaurantLocation;
  menu: string;
  priceRange: string;
  openingHours: string;
  description: string;
  recommendReason: string;
  images: string[];
  authorId: string;
  authorName: string;
  authorPhotoURL?: string;
  likeCount: number;
  commentCount: number;
  viewCount: number;
  reported: boolean;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export type NewRestaurantInput = Omit<
  Restaurant,
  | "id"
  | "likeCount"
  | "commentCount"
  | "viewCount"
  | "reported"
  | "createdAt"
  | "updatedAt"
  | "authorId"
  | "authorName"
  | "authorPhotoURL"
>;

export interface Comment {
  id: string;
  restaurantId: string;
  parentId: string | null;
  content: string;
  authorId: string;
  authorName: string;
  authorPhotoURL?: string;
  createdAt: Timestamp | null;
}

export interface AppUser {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  role: "user" | "admin";
  favorites: string[];
  createdAt: Timestamp | null;
}

export interface Report {
  id: string;
  restaurantId: string;
  reporterId: string;
  reason: string;
  createdAt: Timestamp | null;
  resolved: boolean;
}
